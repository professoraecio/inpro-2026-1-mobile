package com.professoraecio.androidagendaapirest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.professoraecio.androidagendaapirest.controller.ContatoDao;
import com.professoraecio.androidagendaapirest.model.Contato;

public class AddEditContactActivity extends AppCompatActivity {

    Contato contato = new Contato();

    String nome;
    String fone;
    String email;
    EditText editTextNome;
    EditText editTextEmail;
    EditText editTextTelefone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_contact);

        editTextNome = findViewById(R.id.editTextNome);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextTelefone = findViewById(R.id.editTextTelefone);

        Intent intent = getIntent();
        if(intent.hasExtra("contato")){
            contato = (Contato) intent.getSerializableExtra("contato");
            editTextNome.setText(contato.getNome());
            editTextEmail.setText(contato.getEmail());
            editTextTelefone.setText(contato.getFone());
        }
    }

    public void salvarButtonAction(View view){

        nome = editTextNome.getText().toString();
        fone = editTextTelefone.getText().toString();
        email = editTextEmail.getText().toString();


        contato.setNome(nome);
        contato.setFone(fone);
        contato.setEmail(email);

        ContatoDao contatoDao = new ContatoDao();

        if(contato.getId_contato() == 0){
            String response = contatoDao.inserir(contato);
            Toast.makeText(this,response, Toast.LENGTH_LONG).show();
        }else{
            String response = contatoDao.atualizar(contato);
            Toast.makeText(this,response, Toast.LENGTH_LONG).show();
        }


    }
}
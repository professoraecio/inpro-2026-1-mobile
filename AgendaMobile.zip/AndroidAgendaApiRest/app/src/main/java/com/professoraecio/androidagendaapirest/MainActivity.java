package com.professoraecio.androidagendaapirest;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import com.professoraecio.androidagendaapirest.controller.ContatoDao;
import com.professoraecio.androidagendaapirest.http.ContatoParser;
import com.professoraecio.androidagendaapirest.model.ContactAdapter;
import com.professoraecio.androidagendaapirest.model.Contato;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Contato> contatos = new ArrayList<Contato>();

    private ListView listView;
    private ContactAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);


        ContatoDao contatoDao = new ContatoDao();
        ContatoParser contatoParser = new ContatoParser();
        String response = contatoDao.todos();
        contatos = contatoParser.getContatosFromJson(response);

        adapter = new ContactAdapter(this,contatos);
        listView.setAdapter(adapter);



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Contato contato = new Contato();
                contato = contatos.get(position);
                Intent intent = new Intent(MainActivity.this,ContactDetailsActivity.class);
                intent.putExtra("contato",contato);
                startActivity(intent);
            }
        });


        /*
        contato.setId_contato(8);
        contato.setNome("Teste Teste");
        contato.setFone("(99) 99999-9999");
        contato.setEmail("teste@gmail.com");
        */

        /*
        String response = contatoDao.inserir(contato);
        Log.d("debug-mode",response);
        */

        /*
        String response = contatoDao.todos();
        Log.d("debug-mode",response);
         */

        /*
        String response = contatoDao.atualizar(contato);
        Log.d("debug-mode",response);
         */

        /*
        String response = contatoDao.excluir(contato);
        Log.d("debug-mode",response);
         */

        /*
        String response = contatoDao.buscar(contato);
        Log.d("debug-mode",response);
        contato = new Contato();
        contato = contatoParser.getContatoFromJson(response);
        Log.d("debug-mode",contato.getNome());
         */

        /*
        String response = contatoDao.todos();
        Log.d("debug-mode",response);
        contatos = contatoParser.getContatosFromJson(response);
        Log.d("debug-mode","" + contatos.size());
         */

    }

    public void adicionarContato(View view){
        Intent intent = new Intent(this, AddEditContactActivity.class);
        startActivity(intent);
    }

}
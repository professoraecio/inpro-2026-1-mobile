package com.professoraecio.androidagendaapirest.controller;

import com.google.gson.Gson;
import com.professoraecio.androidagendaapirest.http.HttpHelper;
import com.professoraecio.androidagendaapirest.model.Contato;

public class ContatoDao {

    public String toJson(Contato contato){
        Gson gson = new Gson();
        String contatoJson = gson.toJson(contato);
        return  contatoJson;
    }

    // http://192.168.240.1:3000/api.agenda/contato-dao/create
    public String inserir(Contato contato){
        String contatoJson = this.toJson(contato);
        HttpHelper httpHelper = new HttpHelper();
        String reponse = httpHelper.post(contatoJson,"/api.agenda/contato-dao/create");
        return reponse;
    }

    // http://192.168.240.1:3000/api.agenda/contato-dao/getId?id=1
    public String buscar(Contato contato){
        HttpHelper httpHelper = new HttpHelper();
        String response = httpHelper.get("/api.agenda/contato-dao/getId?id=" + contato.getId_contato());
        return response;
    }

    // http://192.168.240.1:3000/api.agenda/contato-dao/getAll
    public String todos(){
        HttpHelper httpHelper = new HttpHelper();
        String response = httpHelper.get("/api.agenda/contato-dao/getAll");
        return response;
    }

    // http://192.168.240.1:3000/api.agenda/contato-dao/updateId
    public String atualizar(Contato contato){
        String contatoJson = this.toJson(contato);
        HttpHelper httpHelper = new HttpHelper();
        String response = httpHelper.post(contatoJson,"/api.agenda/contato-dao/updateId");
        return response;
    }

    // http://192.168.240.1:3000/api.agenda/contato-dao/deleteId
    public String excluir(Contato contato){
        String contatoJson = this.toJson(contato);
        HttpHelper httpHelper = new HttpHelper();
        String response = httpHelper.post(contatoJson,"/api.agenda/contato-dao/deleteId");
        return response;
    }

}

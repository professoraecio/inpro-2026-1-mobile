package com.professoraecio.androidagendaapirest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.professoraecio.androidagendaapirest.controller.ContatoDao;
import com.professoraecio.androidagendaapirest.model.Contato;

public class ContactDetailsActivity extends AppCompatActivity {

    Contato contato = new Contato();

    TextView textViewNome;
    TextView textViewEmail;
    TextView textViewTelefone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_details);

        textViewNome = findViewById(R.id.textViewNome);
        textViewEmail = findViewById(R.id.textViewEmail);
        textViewTelefone = findViewById(R.id.textViewTelefone);

        Intent intent = getIntent();
        if(intent.hasExtra("contato")){
            contato = (Contato) intent.getSerializableExtra("contato");
            textViewNome.setText(contato.getNome());
            textViewEmail.setText(contato.getEmail());
            textViewTelefone.setText(contato.getFone());
        }
    }

    public void editar(View view){
        Intent intent = new Intent(this, AddEditContactActivity.class);
        intent.putExtra("contato",contato);
        startActivity(intent);
    }

    public void excliur(View view){
        ContatoDao contatoDao = new ContatoDao();
        String response = contatoDao.excluir(contato);
        Toast.makeText(this,response,Toast.LENGTH_LONG).show();
    }
}
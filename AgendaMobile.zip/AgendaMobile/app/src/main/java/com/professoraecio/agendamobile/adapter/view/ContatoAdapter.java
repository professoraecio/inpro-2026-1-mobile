package com.professoraecio.agendamobile.adapter.view;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;
import com.professoraecio.agendamobile.R;
import com.professoraecio.agendamobile.model.Contato;
import com.professoraecio.agendamobile.view.ListaContatosActivity;

public class ContatoAdapter extends ArrayAdapter<Contato> {

    public ContatoAdapter(@NonNull ListaContatosActivity context, @NonNull List<Contato> contatos) {
        super(context, 0, contatos);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Contato contato = getItem(position);
        if(convertView == null){
            convertView = LayoutInflater.
                    from(getContext()).inflate(R.layout.contato_cell,parent,false);
        }

        TextView idTextView = convertView.findViewById(R.id.idTextView);
        TextView nomeTextView = convertView.findViewById(R.id.nomeTextView);
        TextView foneTextView = convertView.findViewById(R.id.foneTextView);
        TextView emailTextView = convertView.findViewById(R.id.emailTextView);

        idTextView.setText("" + contato.getId_contato());
        nomeTextView.setText(contato.getNome());
        foneTextView.setText(contato.getFone());
        emailTextView.setText(contato.getEmail());

        return convertView;
    }

}

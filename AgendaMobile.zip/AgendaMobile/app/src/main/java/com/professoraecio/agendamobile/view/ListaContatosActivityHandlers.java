package com.professoraecio.agendamobile.view;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.professoraecio.agendamobile.R;
import com.professoraecio.agendamobile.adapter.view.ContatoAdapter;
import com.professoraecio.agendamobile.model.Contato;
import com.professoraecio.agendamobile.util.UtilProgressBar;

public class ListaContatosActivityHandlers {

    private final ListaContatosActivity controller;

    public ListaContatosActivityHandlers(ListaContatosActivity controller) {
        this.controller = controller;
    }

    private ListView contatosListView;
    private ContatoAdapter contatoAdapter;

    /** Navegação para a tela de detalhes. */
    private void openDetalhesContato(Contato contato) {
        controller.app.contato = contato;
        Intent intent = new Intent(controller, DetalhesContatoActivity.class);
        controller.startActivity(intent);
    }

    /** Busca os contatos na API, atualiza o AppDelegate e notifica o adapter. */
    public void loadAndBind() {
        String response = controller.app.contatoApi.todos();
        controller.mainHandler.post(() -> {
            // volta para UI
            //UtilProgressBar.hide();
            controller.app.contatos = controller.app.contatoParser.getContatosFromJson(response);

            contatoAdapter = new ContatoAdapter(controller,controller.app.contatos);
            contatosListView.setAdapter(contatoAdapter);
        });
    }

    /** Encontra views e liga listeners que não dependem de dados. */
    public void setupView() {
        contatosListView = controller.findViewById(R.id.contatosListView);

        // Adapter inicialmente vazio; os dados chegam em loadAndBind()
        contatoAdapter = new ContatoAdapter(controller, controller.app.contatos);
        contatosListView.setAdapter(contatoAdapter);

        contatosListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id) {
                Contato selecionado = controller.app.contatos.get(pos);
                openDetalhesContato(selecionado);
            }
        });
    }

    /** Ação do botão "Adicionar". */
    public void onAdicionarContato() {
        controller.app.contato = new Contato();
        Intent intent = new Intent(controller, AdicionarEditarContatoActivity.class);
        controller.startActivity(intent);
    }

}

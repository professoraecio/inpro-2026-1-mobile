package com.professoraecio.agendamobile.util;

import android.app.Activity;
import android.os.Build;

import java.lang.ref.WeakReference;
import java.util.concurrent.*;

public class UtilScheduler {

    /**
     * Agenda a execução de um código daqui a X segundos.
     *
     * @param activity Activity usada para rodar na UI thread (caso necessário).
     * @param segundos Quantos segundos esperar antes de executar.
     * @param tarefa   Código a ser executado (Runnable).
     */
    public static void runAfterDelay(Activity activity, int segundos, Runnable tarefa) {
        new android.os.Handler().postDelayed(() -> {
            // Garante execução na UI Thread (necessário se for mexer na interface)
            activity.runOnUiThread(tarefa);
        }, segundos * 1000L); // converte para milissegundos
    }

    private UtilScheduler() {}

    // Executor single-thread em background (daemon) para todos os agendamentos
    private static final ScheduledExecutorService SCHEDULER =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "UtilScheduler");
                t.setDaemon(true);
                return t;
            });

    /** ------------------------- UMA VEZ ------------------------- */

    /** Executa UMA VEZ em background após X segundos. */
    public static ScheduledFuture<?> runAfterDelayBG(long seconds, Runnable task) {
        return SCHEDULER.schedule(task, seconds, TimeUnit.SECONDS);
    }

    /** Executa UMA VEZ na UI Thread após X segundos (seguro contra leaks). */
    public static ScheduledFuture<?> runAfterDelayUI(Activity activity, long seconds, Runnable task) {
        final WeakReference<Activity> ref = new WeakReference<>(activity);
        return SCHEDULER.schedule(() -> {
            Activity act = ref.get();
            if (isAlive(act)) {
                act.runOnUiThread(task);
            }
        }, seconds, TimeUnit.SECONDS);
    }

    /** ---------------------- INDEFINIDAMENTE --------------------- */

    /**
     * Executa INDEFINIDAMENTE em background, a cada 'periodSeconds',
     * após 'initialDelaySeconds'. Usa scheduleAtFixedRate.
     */
    public static ScheduledFuture<?> runEveryBG(long initialDelaySeconds,
                                                long periodSeconds,
                                                Runnable task) {
        return SCHEDULER.scheduleAtFixedRate(task,
                initialDelaySeconds, periodSeconds, TimeUnit.SECONDS);
    }

    /**
     * Executa INDEFINIDAMENTE na UI Thread, a cada 'periodSeconds',
     * após 'initialDelaySeconds'. Usa scheduleAtFixedRate + post na UI.
     * Seguro contra leaks (WeakReference).
     */
    public static ScheduledFuture<?> runEveryUI(Activity activity,
                                                long initialDelaySeconds,
                                                long periodSeconds,
                                                Runnable task) {
        final WeakReference<Activity> ref = new WeakReference<>(activity);
        return SCHEDULER.scheduleAtFixedRate(() -> {
            Activity act = ref.get();
            if (isAlive(act)) {
                act.runOnUiThread(task);
            }
        }, initialDelaySeconds, periodSeconds, TimeUnit.SECONDS);
    }

    /** -------------------------- CONTROLE ------------------------ */

    /** Cancela uma tarefa (delayed ou periódica). */
    public static void cancel(ScheduledFuture<?> future) {
        if (future != null) {
            future.cancel(true); // true = pode interromper se estiver rodando
        }
    }

    /** Encerra o executor (opcional, ex.: no final da aplicação). */
    public static void shutdownNow() {
        SCHEDULER.shutdownNow();
    }

    /** Helper: verifica se a Activity ainda está viva. */
    private static boolean isAlive(Activity act) {
        if (act == null) return false;
        if (act.isFinishing()) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return !act.isDestroyed();
        }
        return true;
    }

}
/*
MODO DE USO

UtilScheduler.runAfterDelay(this, 1, () -> {
    UtilProgressBar.show(this, "Carregando dados...");
});

UtilScheduler.runAfterDelay(this, 5, () -> {
    UtilProgressBar.hide();
});

***********************************************

// 1) UMA VEZ na UI depois de 3s
UtilScheduler.runAfterDelayUI(this, 3, () ->
        UtilProgressBar.show(this, "Carregando dados...")
);

// 2) UMA VEZ em background depois de 5s
ScheduledFuture<?> f1 = UtilScheduler.runAfterDelayBG(5, () -> {
    // tarefa pesada...
});
// cancelar se necessário:
// UtilScheduler.cancel(f1);

// 3) INDEFINIDAMENTE na UI a cada 10s (com atraso inicial de 2s)
ScheduledFuture<?> ticker = UtilScheduler.runEveryUI(this, 2, 10, () -> {
    // atualizar UI periodicamente
    // Ex.: label.setText("Atualizado em " + System.currentTimeMillis());
});

// cancelar quando não precisar mais (ex.: onPause/onDestroy)
@Override
protected void onPause() {
    super.onPause();
    UtilScheduler.cancel(ticker);
}

 */
package com.professoraecio.agendamobile.http;

import android.os.StrictMode;

import android.util.Log;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class HttpHelper {

    // Construtor da classe Estática
    static {
        // Permitir o acesso ao http e não somente https
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.
                        Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    public static final String URL_BASE =
            //"http://192.168.192.1:3000";
            "http://10.0.2.2:3000";

    public String get(String url){
        String responseString = "";
        // Concatenar a URL_BASE com a passada no parâmetro
        final String URL = URL_BASE + url;
        // Montar o meu cabeçalho da requisição
        final MediaType headerHttp =
                MediaType.parse("application/json; charset=UTF-8");
        // O client executará o request
        final OkHttpClient client = new OkHttpClient();
        // Montei a minha requisição baseado na URL criada (não executei)
        Request request = new Request.Builder().url(URL).get().build();
        try{
            Response response = client.newCall(request).execute();
            ResponseBody responseBody = response.body();
            if(responseBody != null){
                // Obtive responsta do servidor
                responseString = responseBody.string();
                Log.d("DEBUG-MODE",responseString);
            }
        }catch (Exception e){
            Log.d("DEBUG-MODE",e.toString());
            responseString = e.toString();
        }
        return responseString;
    }

    public String post(String url, String json){
        String responseString = "";
        // Concatenar a URL_BASE com a passada no parâmetro
        final String URL = URL_BASE + url;
        // Montar o meu cabeçalho da requisição
        final MediaType headerHttp =
                MediaType.parse("application/json; charset=UTF-8");
        // O client executará o request
        final OkHttpClient client = new OkHttpClient();
        final RequestBody body = RequestBody.create(headerHttp,json);
        // Montei a minha requisição baseado na URL criada (não executei)
        Request request = new Request.Builder().url(URL).post(body).build();
        try{
            Response response = client.newCall(request).execute();
            ResponseBody responseBody = response.body();
            if(responseBody != null){
                // Obtive responsta do servidor
                responseString = responseBody.string();
                Log.d("DEBUG-MODE",responseString);
            }
        }catch (Exception e){
            Log.d("DEBUG-MODE",e.toString());
            responseString = e.toString();
        }
        return responseString;
    }

}

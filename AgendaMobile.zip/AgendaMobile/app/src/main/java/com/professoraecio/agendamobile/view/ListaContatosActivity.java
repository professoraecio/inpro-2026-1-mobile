package com.professoraecio.agendamobile.view;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import com.professoraecio.agendamobile.R;
import com.professoraecio.agendamobile.util.UtilAppDelegateViewController;
import com.professoraecio.agendamobile.util.UtilProgressBar;
import com.professoraecio.agendamobile.util.UtilScheduler;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledFuture;

public class ListaContatosActivity extends UtilAppDelegateViewController {

    private ListaContatosActivityHandlers handlers;

    public ExecutorService executor;
    public Handler mainHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_contatos);



        executor = Executors.newSingleThreadExecutor();
        mainHandler = new Handler(Looper.getMainLooper());

        handlers = new ListaContatosActivityHandlers(this);
        handlers.setupView();      // encontra views, configura adapter e listeners


        UtilScheduler.runAfterDelay(this, 0, () -> {
            UtilProgressBar.show(this, "Carregando dados...");
        });

        UtilScheduler.runAfterDelay(this, 3, () -> {
            UtilProgressBar.hide();
        });

        UtilScheduler.runAfterDelay(this, 4, () -> {
            executor.execute(() ->{
                // paralelo (background)
                handlers.loadAndBind();    // carrega os contatos da API e atualiza a lista
            });
        });



        /*
        ScheduledFuture<?> ticker1 = UtilScheduler.runEveryUI(this, 1, 3, () -> {
            UtilProgressBar.show(this, "Carregando dados...");
        });

        ScheduledFuture<?> ticker2 = UtilScheduler.runEveryUI(this, 2, 3, () -> {
            UtilProgressBar.hide();
        });

         */

    }

    @Override
    protected void onStart() {
        super.onStart();
        //UtilProgressBar.show(this,"Carregando lista...");

    }

    @Override
    protected void onResume() {
        super.onResume();
        // Se desejar, recarrega sempre que voltar para esta tela
        handlers.loadAndBind();
    }

    // Botão "Adicionar" no layout aponta para este método (android:onClick)
    public void adicionarContatoButton(View view){
        handlers.onAdicionarContato();
    }

}
package com.professoraecio.agendamobile.util;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class UtilProgressBar {

    // Overlay de tela cheia + card central
    private static FrameLayout overlay;
    private static LinearLayout cardContainer;
    private static ProgressBar progressBar;
    private static TextView textView;

    /**
     * Mostra o loading com mensagem e fundo branco para contraste.
     * @param activity Activity atual.
     * @param mensagem Mensagem a ser exibida abaixo do spinner.
     */
    public static void show(Activity activity, String mensagem) {
        if (overlay == null) {
            // Overlay: cobre a tela toda (fundo levemente translúcido para dar foco)
            overlay = new FrameLayout(activity);
            overlay.setLayoutParams(new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
            ));
            // Fundo translúcido bem claro (quase branco) para não “apagar” a tela por trás
            overlay.setBackgroundColor(Color.parseColor("#CCFFFFFF")); // 80% opaco branco
            overlay.setClickable(true); // intercepta toques

            // Card central branco com cantos arredondados
            cardContainer = new LinearLayout(activity);
            cardContainer.setOrientation(LinearLayout.VERTICAL);
            cardContainer.setGravity(Gravity.CENTER_HORIZONTAL);
            int padding = dp(activity, 20);
            cardContainer.setPadding(padding, padding, padding, padding);

            // Fundo do card com cantos arredondados
            GradientDrawable cardBg = new GradientDrawable();
            cardBg.setColor(Color.WHITE);
            cardBg.setCornerRadius(dp(activity, 16));
            cardContainer.setBackground(cardBg);

            // Elevação sutil (somente Lollipop+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                cardContainer.setElevation(dp(activity, 6));
            }

            // ProgressBar grande indeterminado
            progressBar = new ProgressBar(activity, null, android.R.attr.progressBarStyleLarge);
            progressBar.setIndeterminate(true);

            // Mensagem centralizada
            textView = new TextView(activity);
            textView.setGravity(Gravity.CENTER);
            textView.setTextColor(Color.parseColor("#333333"));
            textView.setTextSize(16);
            textView.setPadding(0, dp(activity, 12), 0, 0);

            // Adiciona componentes ao card
            cardContainer.addView(progressBar);
            cardContainer.addView(textView);

            // Centraliza o card no overlay
            FrameLayout.LayoutParams cardParams = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
            );
            cardParams.gravity = Gravity.CENTER;

            overlay.addView(cardContainer, cardParams);

            // Adiciona overlay na raiz da Activity
            FrameLayout root = activity.findViewById(android.R.id.content);
            root.addView(overlay);
        }

        // Atualiza mensagem (se vazia ou nula, não quebra layout)
        textView.setText(mensagem != null ? mensagem : "");

        overlay.setVisibility(View.VISIBLE);
    }

    /**
     * Esconde o overlay, mantendo-o na hierarquia para reuso.
     */
    public static void hide() {
        if (overlay != null) {
            overlay.setVisibility(View.GONE);
        }
    }

    /**
     * Remove o overlay da tela e limpa referências.
     */
    public static void destroy(Activity activity) {
        if (overlay != null) {
            FrameLayout root = activity.findViewById(android.R.id.content);
            root.removeView(overlay);
            overlay = null;
            cardContainer = null;
            progressBar = null;
            textView = null;
        }
    }

    // Helper para converter dp em px
    private static int dp(Activity activity, int dp) {
        float density = activity.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}


/*
    COMO USAR NA ACTIVITY

    // Exibir o loading
    UtilProgressBar.show(this);

    // Esconder o loading
    UtilProgressBar.hide();

    // Remover totalmente (ex: no onDestroy)
    @Override
    protected void onDestroy() {
    super.onDestroy();
    UtilProgressBar.destroy(this);
}
 */
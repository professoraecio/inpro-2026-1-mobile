package com.professoraecio.agendamobile.view;

import android.text.TextUtils;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.professoraecio.agendamobile.R;
import com.professoraecio.agendamobile.model.Contato;

public class AdicionarEditarContatoActivityHandlers {

    private final AdicionarEditarContatoActivity controller;

    public AdicionarEditarContatoActivityHandlers(AdicionarEditarContatoActivity controller) {
        this.controller = controller;
    }

    private boolean isEditMode = false;
    private Contato working; // objeto sendo editado/criado

    TextView idTextView;
    EditText nomeEditText;
    EditText foneEditText;
    EditText emailEditText;

    public void setupView() {
        idTextView = controller.findViewById(R.id.idTextView);
        nomeEditText = controller.findViewById(R.id.nomeEditText);
        foneEditText = controller.findViewById(R.id.foneEditText);
        emailEditText = controller.findViewById(R.id.emailEditText);
    }

    /**
     * Retorna um texto vazio se o CharSequence for nulo
     */
    private String trimOrEmpty(CharSequence cs) {
        return cs == null ? "" : cs.toString().trim();
    }

    /**
     * Retorna um texto vazio se o String for nulo
     */
    private String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    /**
     * Define sua regra para considerar um ID válido.
     */
    private boolean hasValidId(Contato c) {
        try {
            // Supondo ID inteiro > 0. Ajuste se for String/UUID.
            return c.getId_contato() > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * Verifica se o ID do contato a e igual ao contato b.
     */
    private boolean sameId(Contato a, Contato b) {
        try {
            return a.getId_contato() == b.getId_contato();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Clona campos principais para evitar efeitos colaterais antes do salvar.
     */
    private Contato cloneContato(Contato src) {
        Contato copy = new Contato();
        try {
            copy.setId_contato(src.getId_contato());
        } catch (Exception ignored) {
        }
        copy.setNome(src.getNome());
        copy.setFone(src.getFone());
        copy.setEmail(src.getEmail());
        return copy;
    }

    /**
     * Preenche campos de texto a partir do modelo.
     */
    private void fillFieldsFromModel(Contato c) {
        idTextView.setText(nullToEmpty("" + c.getId_contato()));
        nomeEditText.setText(nullToEmpty(c.getNome()));
        foneEditText.setText(nullToEmpty(c.getFone()));
        emailEditText.setText(nullToEmpty(c.getEmail()));
    }

    /**
     * Lê campos da UI para o modelo e valida.
     */
    private boolean readAndValidateFieldsIntoModel() {
        String nome = trimOrEmpty(nomeEditText.getText());
        String fone = trimOrEmpty(foneEditText.getText());
        String email = trimOrEmpty(emailEditText.getText());

        // Validações simples (ajuste conforme sua regra de negócio)
        if (TextUtils.isEmpty(nome)) {
            nomeEditText.setError("Informe o nome");
            nomeEditText.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(fone)) {
            foneEditText.setError("Informe o telefone");
            foneEditText.requestFocus();
            return false;
        }

        if (TextUtils.isEmpty(email)) {
            emailEditText.setError("Informe o e-mail");
            emailEditText.requestFocus();
            return false;
        }

        // Preenche o modelo
        working.setNome(nome);
        working.setFone(fone);
        working.setEmail(email);
        return true;
    }

    /**
     * Se houver contato no AppDelegate, considera edição e preenche os campos.
     * Caso contrário, prepara um novo Contato.
     */
    public void bindOrPrepare() {
        Contato atual = controller.app.contato;
        if (atual != null && hasValidId(atual)) {
            isEditMode = true;
            working = cloneContato(atual); // evita mutar o objeto global antes de salvar
            fillFieldsFromModel(working);
        } else {
            isEditMode = false;
            working = new Contato();
        }
    }

    /** Fecha a tela sem salvar. */
    public void onCancelar() {
        controller.finish();
    }

    /** Ação do botão Salvar. Faz validação, chama API e finaliza. */
    public void onSalvar() {
        if (!readAndValidateFieldsIntoModel()) {
            return;
        }
        try {
            boolean sucesso;
            if (isEditMode) {
                String response = controller.app.contatoApi.atualizar(working);
                sucesso = response.contains("Contato atualizado com sucesso!") ? true : false;
            } else {
                String response = controller.app.contatoApi.inserir(working);
                sucesso = response.contains("Contato cadastrado com sucesso!") ? true : false;
            }
            if (sucesso) {
                controller.app.contato = working;
                if (controller.app.contatos != null) {
                    if (isEditMode) {
                        // substitui na lista o item editado (por id)
                        for (int i = 0; i < controller.app.contatos.size(); i++) {
                            Contato c = controller.app.contatos.get(i);
                            if (sameId(c, working)) {
                                controller.app.contatos.set(i, working);
                                break;
                            }
                        }
                    } else {
                        controller.app.contatos.add(working);
                    }
                }

                Toast.makeText(controller, isEditMode ? "Contato atualizado." : "Contato cadastrado.", Toast.LENGTH_SHORT).show();
                controller.finish();
            } else {
                Toast.makeText(controller, "Não foi possível salvar. Tente novamente.", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(controller, "Erro ao salvar: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

}

package com.professoraecio.agendamobile.singleton;

import android.app.Application;
import com.professoraecio.agendamobile.api.ContatoApi;
import com.professoraecio.agendamobile.http.ContatoParser;
import com.professoraecio.agendamobile.model.Contato;
import java.util.ArrayList;

public class AppDelegate extends Application {

    public Contato contato = new Contato();
    public ContatoApi contatoApi = new ContatoApi();
    public ContatoParser contatoParser = new ContatoParser();
    public ArrayList<Contato> contatos = new ArrayList<Contato>();

}

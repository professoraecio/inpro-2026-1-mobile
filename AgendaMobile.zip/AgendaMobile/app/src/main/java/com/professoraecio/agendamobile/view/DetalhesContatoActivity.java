package com.professoraecio.agendamobile.view;

import android.os.Bundle;
import android.view.View;
import com.professoraecio.agendamobile.R;
import com.professoraecio.agendamobile.util.UtilAppDelegateViewController;

public class DetalhesContatoActivity extends UtilAppDelegateViewController {

    private DetalhesContatoActivityHandlers handlers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_contato);

        handlers = new DetalhesContatoActivityHandlers(this);
        handlers.setupView();   // encontra as views
        handlers.bindData();    // preenche os TextViews com app.contato
    }

    @Override
    protected void onResume() {
        super.onResume();
        handlers.bindData(); // força atualização antes de exibir
    }

    // Botões do layout podem apontar para estes métodos via android:onClick
    public void editarButton(View view){
        handlers.onEditarContato();
    }

    public void excluirButton(View view){
        handlers.onExcluirContato();
    }

    public void cancelarButton(View view){
        handlers.onCancelar();
    }
}
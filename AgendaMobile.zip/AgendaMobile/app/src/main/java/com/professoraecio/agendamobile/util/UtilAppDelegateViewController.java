package com.professoraecio.agendamobile.util;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import com.professoraecio.agendamobile.singleton.AppDelegate;

public class UtilAppDelegateViewController extends AppCompatActivity {

    public AppDelegate app;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        app = (AppDelegate) getApplication();
        AppCompatDelegate.
                setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                // forçar claro
    }

}

package com.professoraecio.agendamobile.view;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.widget.TextView;
import android.widget.Toast;

import com.professoraecio.agendamobile.R;
import com.professoraecio.agendamobile.model.Contato;

public class DetalhesContatoActivityHandlers {

    private final DetalhesContatoActivity controller;

    public DetalhesContatoActivityHandlers(DetalhesContatoActivity controller) {
        this.controller = controller;
    }

    TextView idTextView;
    TextView nomeTextView;
    TextView foneTextView;
    TextView emailTextView;

    public void setupView() {
        idTextView = controller.findViewById(R.id.idTextView);
        nomeTextView  = controller.findViewById(R.id.nomeTextView);
        foneTextView  = controller.findViewById(R.id.foneTextView);
        emailTextView = controller.findViewById(R.id.emailTextView);
    }

    /** Preenche as views com os dados do contato atual no AppDelegate. */
    public void bindData() {
        Contato c = controller.app.contato;
        if (c == null) {
            Toast.makeText(controller, "Contato não encontrado.", Toast.LENGTH_SHORT).show();
            controller.finish();
            return;
        }
        // Ajuste os getters conforme seu modelo:
        idTextView.setText("" + c.getId_contato());
        nomeTextView.setText(c.getNome());
        foneTextView.setText(c.getFone());
        emailTextView.setText(c.getEmail());
    }

    /** Abre a tela de edição reutilizando o contato atual (app.contato). */
    public void onEditarContato() {
        Intent intent = new Intent(controller, AdicionarEditarContatoActivity.class);
        controller.startActivity(intent);
    }

    public void onExcluirContato() {
        Contato c = controller.app.contato;
        if (c == null) {
            Toast.makeText(controller, "Contato inválido.", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(controller)
                .setTitle("Excluir contato")
                .setMessage("Tem certeza que deseja excluir este contato?")
                .setPositiveButton("Excluir", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        try {
                            // Ajuste o método conforme sua API (id/getId etc.)
                            String response = controller.app.contatoApi.excluir(c);
                            if (response.contains("Contato excluído com sucesso!")) {
                                Toast.makeText(controller, "Contato excluído.", Toast.LENGTH_SHORT).show();
                                // Opcional: remover da lista em memória para refletir ao voltar
                                if (controller.app.contatos != null) {
                                    controller.app.contatos.remove(c);
                                }
                                controller.finish(); // volta para a lista
                            } else {
                                Toast.makeText(controller, "Falha ao excluir.", Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                            Toast.makeText(controller, "Erro: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Fecha a tela de detalhes. */
    public void onCancelar() {
        controller.finish();
    }

}

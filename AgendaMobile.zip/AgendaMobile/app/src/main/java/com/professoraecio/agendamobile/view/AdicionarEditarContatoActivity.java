package com.professoraecio.agendamobile.view;

import android.os.Bundle;
import android.view.View;
import com.professoraecio.agendamobile.R;
import com.professoraecio.agendamobile.util.UtilAppDelegateViewController;

public class AdicionarEditarContatoActivity extends UtilAppDelegateViewController {

    private AdicionarEditarContatoActivityHandlers handlers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adicionar_editar_contato);

        handlers = new AdicionarEditarContatoActivityHandlers(this);
        handlers.setupView();       // encontra as views
        handlers.bindOrPrepare();   // se for edição, preenche campos; senão, prepara para novo
    }

    public void salvarAtualizarButton(View view){
        handlers.onSalvar();
    }

    public void cancelarButton(View view){
        handlers.onCancelar();
    }
}